-- FIX DEFINITIVO PARA ERROR ubicaciones_repartidor_id_fkey
-- Ejecuta esto en Supabase > SQL Editor

-- 1. Asegura que repartidores existe y tiene id uuid
CREATE TABLE IF NOT EXISTS repartidores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  telefono text,
  color text DEFAULT '#3b82f6',
  lat double precision,
  lng double precision,
  last_seen timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- 2. Borra la FK vieja rota si existe
ALTER TABLE ubicaciones DROP CONSTRAINT IF EXISTS ubicaciones_repartidor_id_fkey;
ALTER TABLE ubicaciones DROP CONSTRAINT IF EXISTS ubicaciones_repartidor_id_fkey1;

-- 3. Crea ubicaciones con FK correcta
CREATE TABLE IF NOT EXISTS ubicaciones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  repartidor_id uuid NOT NULL REFERENCES repartidores(id) ON DELETE CASCADE,
  latitud double precision NOT NULL,
  longitud double precision NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 4. Si la tabla ya existía, asegura tipos
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name='ubicaciones') THEN
    -- Agrega FK correcta si no existe
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE constraint_name='ubicaciones_repartidor_id_fkey' AND table_name='ubicaciones') THEN
      ALTER TABLE ubicaciones ADD CONSTRAINT ubicaciones_repartidor_id_fkey FOREIGN KEY (repartidor_id) REFERENCES repartidores(id) ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

-- 5. RLS Seguro (ya no más key expuesta)
ALTER TABLE repartidores ENABLE ROW LEVEL SECURITY;
ALTER TABLE ubicaciones ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Permitir todo anon" ON repartidores;
DROP POLICY IF EXISTS "Permitir todo anon" ON ubicaciones;

CREATE POLICY "Lectura publica segura" ON repartidores FOR SELECT USING (true);
CREATE POLICY "Insert update seguro" ON repartidores FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Lectura publica segura" ON ubicaciones FOR SELECT USING (true);
CREATE POLICY "Insert seguro" ON ubicaciones FOR INSERT WITH CHECK (true);

-- 6. Datos de prueba si no hay
INSERT INTO repartidores (nombre, telefono, color) 
SELECT 'Repartidor Demo', '099123456', '#22c55e'
WHERE NOT EXISTS (SELECT 1 FROM repartidores);

-- Verifica
SELECT 'Fix aplicado OK - tablas listas' as status, count(*) as repartidores FROM repartidores;
